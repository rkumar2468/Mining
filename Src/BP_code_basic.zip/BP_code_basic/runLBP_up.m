function runLBP_up(adjlist,edgep,signed)

ind=find(adjlist(:,3)==-1);
adjlist(ind,3)=2;

N = length(unique(adjlist(:,1)));
M = length(unique(adjlist(:,2)));

upriors = ones(N,2)*0.5;
%upriors(3,:)=[ 0.01 0.99];
%upriors(4,:)=[ 0.01 0.99];
%upriors(5,:)=[ 0.01 0.99];
%upriors(1,:)= [ 0.9 0.1];
%upriors(2,:)= [ 0.9 0.1];
%upriors(6,:)= [ 0.9 0.1];


ppriors = ones(M,2)*0.5;
%ppriors(3,:)=[ 0.01 0.99];

if(signed)    
[beliefs1, beliefs2, Hi] = LBP_signed_up( adjlist, upriors, ppriors, edgep, 100 )
else
%[beliefs1, beliefs2, Hi] = LBP_unsigned_up( adjlist, upriors, ppriors, edgep(:,:,1), 1000 )
[beliefs1, beliefs2, Hi] = LBP_unsigned_up_v2( adjlist, upriors, ppriors, edgep(:,:,1), 1000 )
end

end